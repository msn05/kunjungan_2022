<?php
define('Controller', 'http://localhost/kunjungan_inspektorat_prov/');
define('DOC_ROOT', 'http://localhost/kunjungan_inspektorat_prov/public');
define('Vendor', 'http://localhost/kunjungan_inspektorat_prov/vendor/');
