<?php

namespace Config;

trait Config
{
  protected $driver = 'mysql';
  protected $host   = 'localhost';
  protected $db     = 'db_kunjungan';
  protected $user   = 'root';
  protected $password = 'Akamsi123';
  protected $port   = 3306;
}
